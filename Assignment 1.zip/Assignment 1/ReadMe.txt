Andy Pham - 101006098

Developed under Windows 10 OS
Tested with Chrome Browser
Use http://localhost:3000/assignment1.html to launch the web app


Run Assignment1.Server on the current directory it is at, so basically on the "Assignment 1" folder

After opening a requested song by pressing enter or clicking on the "Open" button , always click on the 
canvas afterwards as the chords and lyrics will show up on the canvas for some reason